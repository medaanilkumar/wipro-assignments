UPDATE MY_EMPLOYEE SET salary= salary + (salary * 10 / 100) WHERE DEPARTMENT_ID = 90;
select * from MY_EMPLOYEE;