
public class Assignment4 {

	public static void main(String[] args) {
		char x = 'e';
		char y = 'a';
		
		if (x < y) {
			System.out.println(x + ", " + y);
		} else {
			System.out.println(y + ", " + x);
		}

	}

}