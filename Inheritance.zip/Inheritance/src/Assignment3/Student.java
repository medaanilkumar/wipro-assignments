package Assignment3;
public class Student extends Person {
	private int roll;
}
