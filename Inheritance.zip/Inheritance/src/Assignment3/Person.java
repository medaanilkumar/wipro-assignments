package Assignment3;
public class Person {
	private String name;
}
