package TM10_Project06;

import java.util.ArrayList;
import java.util.Scanner;

public class stringEdit {

	public static void main(String[] args) {
		ArrayList<String> br = new ArrayList<String>();
		String str = "JAVAJAVA";
		String shrt = "VA";
		// case1
		StringBuilder sb = new StringBuilder("");
		for (int i = 0; i <= str.length() - 1; i++) {
			if (i % 2 == 0) {
				sb.append(shrt);
			} else {
				sb.append(str.charAt(i));
			}
		}
		String s = sb.toString();
		int j = 0;
		br.add(j, s);
		j++;

		// case2
		int count = 0;
		for (int i = 0; i <= str.length() - 1; i++) {
			for (int k = i + 1; k <= str.length(); k++) {
				String ans = str.substring(i, k);
				if (ans.equals(shrt)) {
					count++;
				}
			}
		}
		if (count > 1) {
			int l = shrt.length();
			StringBuilder b = new StringBuilder("");
			for (int i = 0; i < str.length() - l; i++) {
				b.append(str.charAt(i));
			}
			StringBuilder r = new StringBuilder();
			for (int i = shrt.length() - 1; i >= 0; i--) {
				r.append(shrt.charAt(i));
			}
			String c = b.toString() + r.toString();
			br.add(j, c);
			j++;
		} else {
			String a = str + shrt;
			br.add(j, a);
			j++;
		}

		// case3
		int count1 = 0;
		for (int i = 0; i <= str.length() - 1; i++) {
			for (int k = i + 1; k <= str.length(); k++) {
				String ans = str.substring(i, k);
				if (ans.equals(shrt)) {
					count1++;
				}
			}
		}
		if (count1 > 1) {
			StringBuilder z = new StringBuilder(str);
			for (int i = 0; i < str.length() - 1; i++) {
				for (int k = i + 1; k <= str.length(); k++) {
					String y = str.substring(i, k);
					if (y.equals(shrt)) {
						z.delete(i, k);
					}
				}

			}
			br.add(j, z.toString());
			j++;
		} else {
			br.add(j, str);
			j++;
		}
		// case4
		StringBuilder fh = new StringBuilder();
		int i = 0;
		for (; i <= (shrt.length() - 1) / 2; i++) {
			fh.append(shrt.charAt(i));
		}
		StringBuilder sh = new StringBuilder();
		for (; i <= shrt.length() - 1; i++) {
			sh.append(shrt.charAt(i));
		}
		String ans1 = fh.toString() + str;
		String finalans = ans1 + sh;
		br.add(j, finalans);
		j++;

		// case5
		StringBuilder t = new StringBuilder(str);
		for (int c = 0; c < str.length(); c++) {
			for (int d = 0; d < shrt.length(); d++) {
				if (str.charAt(c) == shrt.charAt(d)) {
					t.setCharAt(c, '*');
					break;
				}
			}
		}
		br.add(j, t.toString());
		j++;
		System.out.println(br);
	}

}
