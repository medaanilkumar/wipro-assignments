import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
		LinkedList<String> l= new LinkedList<String>();
		l.addLast("JANUARY");
		l.addLast("FEBRUARY");
		l.addLast("MARCH");
		l.addLast("APRIL");
		l.addLast("MAY");
		l.addLast("JUNE");
		l.add("JULY");
		l.add("AUGUST");
		l.add("SEPTEMBER");
		l.add("OCTOBER");
		l.add("NOVEMBER");
		l.add("DECEMBER");
		System.out.println(l);
	}
}


