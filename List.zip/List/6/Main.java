import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
		Vector<String> l= new Vector<String>();
		l.addElement("JANUARY");
		l.addElement("FEBRUARY");
		l.addElement("MARCH");
		l.addElement("APRIL");
		l.addElement("MAY");
		l.addElement("JUNE");
		l.add("JULY");
		l.add("AUGUST");
		l.add("SEPTEMBER");
		l.add("OCTOBER");
		l.add("NOVEMBER");
		l.add("DECEMBER");
		System.out.println(l);
	}
}


