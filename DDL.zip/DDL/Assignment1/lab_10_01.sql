CREATE TABLE DEPTS
	(Dept_ID NUMBER(7),
	Dept_Name VARCHAR2(25),
constraint pk_DEPTS primary key (Dept_ID));
	
	DESCRIBE DEPTS;