package Assignment1;
public class Assignment1 {

	public static void main(String[] args) {
		new Fruit().eat();
		new Apple().eat();
		new Orange().eat();

	}

}
