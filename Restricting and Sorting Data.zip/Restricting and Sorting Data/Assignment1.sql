/* Create a report that displays the last name and salary of employees who earn more than $12,000. */

SQL> select last_name, salary from employees where salary > 12000;

LAST_NAME                     SALARY
------------------------- ----------
King                           24000
Kochhar                        17000
De Haan                        17000
Greenberg                      12008
Russell                        14000
Partners                       13500
Hartstein                      13000
Higgins                        12008