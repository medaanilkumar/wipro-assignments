/*  List employees who earn between $5,000 and $12,000, and are in department 20 or 50. Label the columns as
Employee and Monthly Salary, respectively. */

SQL> select last_name "Employee", salary "Monthly Salary" from employees where (salary between 5000 and 12000) and department_id in (20,50);

Employee                  Monthly Salary
------------------------- --------------
Weiss                               8000
Fripp                               8200
Kaufling                            7900
Vollman                             6500
Mourgos                             5800
Fay                                 6000

6 rows selected.