/* Create a report to display the last name and job title of all employees who do not have a manager. */

SQL> select last_name, job_id
  2  from employees
  3  where manager_id is null;

LAST_NAME                 JOB_ID
------------------------- ----------
King                      AD_PRES