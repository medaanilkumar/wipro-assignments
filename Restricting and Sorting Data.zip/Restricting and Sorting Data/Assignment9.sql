/* Create a report to display the last name, salary, and commission of all employees who earn commissions. 
Sort data in descending order based on salary and commissions. Use the column’s numeric position in the ORDER BY clause. */


 SQL> select last_name, salary, commission_pct
  2   from employees
  3   where commission_pct is not null
  4   order by salary desc, commission_pct desc;

LAST_NAME                     SALARY COMMISSION_PCT
------------------------- ---------- --------------
Russell                        14000             .4
Partners                       13500             .3
Errazuriz                      12000             .3
Ozer                           11500            .25
Cambrault                      11000             .3
Abel                           11000             .3
Vishney                        10500            .25
Zlotkey                        10500             .2
King                           10000            .35
Tucker                         10000             .3
Bloom                          10000             .2

LAST_NAME                     SALARY COMMISSION_PCT
------------------------- ---------- --------------
Fox                             9600             .2
Sully                           9500            .35
Bernstein                       9500            .25
Greene                          9500            .15
McEwen                          9000            .35
Hall                            9000            .25
Hutton                          8800            .25
Taylor                          8600             .2
Livingston                      8400             .2
Smith                           8000             .3
Olsen                           8000             .2

LAST_NAME                     SALARY COMMISSION_PCT
------------------------- ---------- --------------
Doran                           7500             .3
Cambrault                       7500             .2
Smith                           7400            .15
Bates                           7300            .15
Marvins                         7200             .1
Sewall                          7000            .25
Tuvault                         7000            .15
Grant                           7000            .15
Lee                             6800             .1
Ande                            6400             .1
Banda                           6200             .1

LAST_NAME                     SALARY COMMISSION_PCT
------------------------- ---------- --------------
Johnson                         6200             .1
Kumar                           6100             .1

35 rows selected.