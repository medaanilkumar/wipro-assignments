/* Display the last names of all employees who have both an “a” and an “e” in their last name. */

SQL> select last_name from employees
  2   where last_name like '%a%' and last_name like '%e%';

LAST_NAME
-------------------------
Baer
Bates
Colmenares
Davies
De Haan
Faviet
Fleaur
Gates
Hartstein
Markle
Nayer

LAST_NAME
-------------------------
Partners
Patel
Philtanker
Raphaely
Sewall
Whalen

17 rows selected.
