/*   Create a report that displays the last name and department number for employee number 176. */

SQL> select last_name, department_id from employees where employee_id = 176;

LAST_NAME                 DEPARTMENT_ID
------------------------- -------------
Taylor                               80

