/* Create a query that prompts the user for a manager ID and generates the employee ID, last name, salary and department for that manager’s employees and
prompts a column name by which result should be sorted.
Eg:
manager_id :103
sorted_by : last_name */


SQL> select employee_id, last_name, salary, department_id from employees
  2  where manager_id= &manager
  3  order by last_name;
Enter value for manager: 103
old   2: where manager_id= &manager
new   2: where manager_id= 103

EMPLOYEE_ID LAST_NAME                     SALARY DEPARTMENT_ID
----------- ------------------------- ---------- -------------
        105 Austin                          4800            60
        104 Ernst                           6000            60
        107 Lorentz                         4200            60
        106 Pataballa                       4800            60
