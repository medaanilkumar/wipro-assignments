/* Create a report to display the last name, job ID, and hire date for employees with the last names of Matos and Taylor. Order the query in ascending order by the hire date. */ 

SQL> select last_name, job_id, hire_date from employees where last_name='Matos' or last_name='Taylor' order by hire_date;

LAST_NAME                 JOB_ID     HIRE_DATE
------------------------- ---------- ---------
Taylor                    SH_CLERK   24-JAN-06
Matos                     ST_CLERK   15-MAR-06
Taylor                    SA_REP     24-MAR-06
