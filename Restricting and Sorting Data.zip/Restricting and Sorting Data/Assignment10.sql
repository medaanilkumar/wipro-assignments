/*  Create a report that displays the last name and salary of employees who earn more than an amount that the user specifies after a prompt. 
If you enter 12000, it should display all employees earning more than 12000.
Eg: Salary_value: 12000. */

SQL> select last_name, salary from employees  where salary> &Salary;
Enter value for salary: 12000
old   3: where salary> &Salary
new   3: where salary> 12000

LAST_NAME                     SALARY
------------------------- ----------
King                           24000
Kochhar                        17000
De Haan                        17000
Greenberg                      12008
Russell                        14000
Partners                       13500
Hartstein                      13000
Higgins                        12008

8 rows selected.
