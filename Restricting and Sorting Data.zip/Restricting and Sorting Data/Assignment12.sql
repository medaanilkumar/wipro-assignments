/* Display all employee last names in which the third letter of the name is “a”. */

SQL> select last_name
  2   from employees
  3   where last_name like '__a%';

LAST_NAME
-------------------------
Grant
Grant
Whalen