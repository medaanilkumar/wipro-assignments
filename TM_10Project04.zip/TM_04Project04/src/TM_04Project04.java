

import java.util.ArrayList;

import java.util.HashMap;
import java.util.Scanner;

public class TM_04Project04 {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int n = scn.nextInt();
		HashMap<Character, ArrayList<Integer>> map = new HashMap<Character, ArrayList<Integer>>();
		while (n > 0) {
			char ch = scn.next().charAt(0);
			int p = scn.nextInt();
			if (map.containsKey(ch)) {
				int idx = map.get(ch).size();
				map.get(ch).add(idx, p);

			} else {
				ArrayList<Integer> br = new ArrayList<Integer>();
				br.add(0, p);
				map.put(ch, br);
			}
			n--;
		}

		System.out.println("Distinct Symbols are : ");
		for (Character ch : map.keySet()) {
			System.out.println(ch + " ");
		}

		for (Character ch : map.keySet()) {
			int i = 0;
			int sum = 0;
			ArrayList<Integer> mr = map.get(ch);
			while (i < mr.size()) {
				int a = mr.get(i);
				sum += a;
				System.out.println(ch + " " + a);
				i++;
			}
			System.out.println("No. of cards" + ":" + i);
			System.out.println("Sum of Numbers :" + sum);
		}

	}

}
