package automobile.twowheeler;

import automobile.vehicle;

public class hero extends vehicle {
	private String modelname;
	private String registrationo;
	private String ownername;
	private int speed;
	
	public hero(String modelname, String registrationo, String ownername, int speed) {
		super();
		this.modelname = modelname;
		this.registrationo = registrationo;
		this.ownername = ownername;
		this.speed = speed;
	}
	
	@Override
	public void getmodelname() {
		System.out.println("modelname: " + modelname);
	}
	
	@Override
	public void getregistrationno() {
		System.out.println("registrationNumber: " + registrationo);
	}
	
	@Override
	public void getownername() {
		System.out.println("ownername "+ownername);
	}
	
	public int getSpeed() {
		return speed;
	}
	
	public void radio() {
		System.out.println("Accessing the radio");
	}
}
