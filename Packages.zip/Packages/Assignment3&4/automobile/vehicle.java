package automobile;

public abstract class vehicle {
	public abstract void getmodelname();
	public abstract void getregistrationno();
	public abstract void getownername();
}
