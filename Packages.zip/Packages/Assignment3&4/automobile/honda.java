package automobile;

public class honda extends vehicle {
	
	private String modelname;
	private String registrationo;
	private String ownername;
	private int speed;
	
	public honda(String modelname, String registrationo, String ownername, int speed) {
		super();
		this.modelname = modelname;
		this.registrationo = registrationo;
		this.ownername = ownername;
		this.speed = speed;
	}
	
	@Override
	public void getmodelname() {
		System.out.println("modelname: " + modelname);
	}
	
	@Override
	public void getregistrationno() {
		System.out.println("registrationNumber: " + registrationo);
	}
	
	@Override
	public void getownername() {
		System.out.println("ownername "+ownername);
	}
	
	public int speed() {
		return speed;
	}
	
	public void cdplayer() {
		System.out.println("Accessing CD Player.");
	}
}
