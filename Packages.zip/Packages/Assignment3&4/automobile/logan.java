package automobile;

public class logan extends vehicle {
	private String modelname;
	private String registrationo;
	private String ownername;
	private int speed;
	private int gps;
	
	public logan(String modelname, String registrationo, String ownername, int speed, int gps) {
		super();
		this.modelname = modelname;
		this.registrationo = registrationo;
		this.ownername = ownername;
		this.speed = speed;
		this.gps = gps;
	}
	
	@Override
	public void getmodelname() {
		System.out.println("modelname: " + modelname);
	}
	
	@Override
	public void getregistrationno() {
		System.out.println("registrationNumber: " + registrationo);
	}
	
	@Override
	public void getownername() {
		System.out.println("ownername "+ownername);
	}
	
	public int speed() {
		return speed;
	}
	
	public int gps() {
		return gps;
	}
}
