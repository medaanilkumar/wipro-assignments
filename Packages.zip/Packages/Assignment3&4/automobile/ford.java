package automobile;

public class ford extends vehicle{
	private String modelname;
	private String registrationo;
	private String ownername;
	private int speed;
	private int control;
	
	private ford(String modelname, String registrationo, String ownername, int speed, int control) {
		super();
		this.modelname = modelname;
		this.registrationo = registrationo;
		this.ownername = ownername;
		this.speed = speed;
		this.control = control;
	}
	
	@Override
	public void getmodelname() {
		System.out.println("modelname: " + modelname);
	}
	
	@Override
	public void getregistrationno() {
		System.out.println("registrationNumber: " + registrationo);
	}
	
	@Override
	public void getownername() {
		System.out.println("ownername "+ownername);
	}
	
	public int speed() {
		return speed;
	}
	
	public int control() {
		return control;
	}
}
