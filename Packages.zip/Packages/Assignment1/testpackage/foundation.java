package testpackage;

public class foundation {
	private int check1;
	int check2;
	protected int check3;
	public int check4;
}
