package packagepacks;

import testpackage.foundation;

public class assignment1 {
	public static void main(String[] args) {
		foundation founds = new foundation();
		
		founds.check4 = 5;
		
		System.out.println(founds.check4);
	}
}
