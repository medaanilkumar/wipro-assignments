package Assignment2;

public class General extends Compartment {

	@Override
	public void notice() {
		System.out.println("Notice: You're in General");
	}

}