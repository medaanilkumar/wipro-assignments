package Assignment2;

public class FirstClass extends Compartment {

	@Override
	public void notice() {
		System.out.println("Notice: You're in FirstClass");
	}

}