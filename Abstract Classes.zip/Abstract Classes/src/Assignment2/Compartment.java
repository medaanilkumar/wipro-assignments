package Assignment2;

public abstract class Compartment {
	public abstract void notice();
}